package com.test.vehicle.parking;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.vehicle.parking.exception.ParkingVehicleException;
import com.vehicle.parking.exception.VehicleErrorCode;
import com.vehicle.parking.model.Car;
import com.vehicle.parking.service.ParkingVehicleService;
import com.vehicle.parking.service.impl.ParkingVehicleServiceImpl;

/**
 * @author kiran
 */
public class ParkingVehicleTest
{
	private final ByteArrayOutputStream	byteArrayOutputStream	= new ByteArrayOutputStream();
	private int							parkingSlot;
	ParkingVehicleService				instance				= new ParkingVehicleServiceImpl();
	
	@Rule
	public ExpectedException thrown = ExpectedException.none();
	
	@Before
	public void init()
	{
		parkingSlot = 1;
		System.setOut(new PrintStream(byteArrayOutputStream));
	}
	
	@After
	public void cleanUp()
	{
		System.setOut(null);
	}
	
	@Test
	public void createParkingLot() throws Exception
	{
		instance.createParkingLot(parkingSlot, 6);
		assertTrue("createdparkinglotwith6slots"
				.equalsIgnoreCase(byteArrayOutputStream.toString().trim().replace(" ", "")));
		instance.doCleanup();
	}
	
	@Test
	public void alreadyExistParkingLot() throws Exception
	{
		instance.createParkingLot(parkingSlot, 6);
		assertTrue("createdparkinglotwith6slots"
				.equalsIgnoreCase(byteArrayOutputStream.toString().trim().replace(" ", "")));
		thrown.expect(ParkingVehicleException.class);
		thrown.expectMessage(is(VehicleErrorCode.PARKING_ALREADY_EXIST.getMessage()));
		instance.createParkingLot(parkingSlot, 6);
		instance.doCleanup();
	}
	
	@Test
	public void testParkingCapacity() throws Exception
	{
		thrown.expect(ParkingVehicleException.class);
		thrown.expectMessage(is(VehicleErrorCode.PARKING_NOT_EXIST_ERROR.getMessage()));
		instance.park(parkingSlot, new Car("KA-01-HH-1234", "White"));
		assertEquals("Sorry,CarParkingDoesnotExist", byteArrayOutputStream.toString().trim().replace(" ", ""));
		instance.createParkingLot(parkingSlot, 6);
		instance.park(parkingSlot, new Car("KA-01-HH-1234", "White"));
		instance.park(parkingSlot, new Car("KA-01-HH-9999", "White"));
		instance.park(parkingSlot, new Car("KA-01-BB-0001", "Black"));
		assertEquals(3, instance.fetchAvailableSlotsCount(parkingSlot));
		instance.doCleanup();
	}
	
	@Test
	public void testEmptyParkingLot() throws Exception
	{
		thrown.expect(ParkingVehicleException.class);
		thrown.expectMessage(is(VehicleErrorCode.PARKING_NOT_EXIST_ERROR.getMessage()));
		instance.fetchStatus(parkingSlot);
		assertTrue("Sorry,CarParkingDoesnotExist"
				.equalsIgnoreCase(byteArrayOutputStream.toString().trim().replace(" ", "")));
		instance.createParkingLot(parkingSlot, 6);
		instance.fetchStatus(parkingSlot);
		assertTrue(
				"Sorry,CarParkingDoesnotExist\ncreatedparkinglotwith6slots\nSlotNo.\tRegistrationNo.\tColor\nSorry,parkinglotisempty."
						.equalsIgnoreCase(byteArrayOutputStream.toString().trim().replace(" ", "")));
		instance.doCleanup();
	}
	
	@Test
	public void testParkingLotIsFull() throws Exception
	{
		thrown.expect(ParkingVehicleException.class);
		thrown.expectMessage(is(VehicleErrorCode.PARKING_NOT_EXIST_ERROR.getMessage()));
		instance.park(parkingSlot, new Car("KA-01-HH-1234", "White"));
		assertEquals("Sorry,CarParkingDoesnotExist", byteArrayOutputStream.toString().trim().replace(" ", ""));
		instance.createParkingLot(parkingSlot, 6);
		instance.park(parkingSlot, new Car("KA-01-HH-1234", "White"));
		instance.park(parkingSlot, new Car("KA-01-HH-9999", "White"));
		instance.park(parkingSlot, new Car("KA-01-BB-0001", "Black"));
		assertTrue("createdparkinglotwith2slots\\nAllocatedslotnumber:1\nAllocatedslotnumber:2\nSorry,parkinglotisfull"
				.equalsIgnoreCase(byteArrayOutputStream.toString().trim().replace(" ", "")));
		instance.doCleanup();
	}
	
	@Test
	public void testNearestSlotAllotment() throws Exception
	{
		thrown.expect(ParkingVehicleException.class);
		thrown.expectMessage(is(VehicleErrorCode.PARKING_NOT_EXIST_ERROR.getMessage()));
		instance.park(parkingSlot, new Car("KA-01-HH-1234", "White"));
		assertEquals("Sorry,CarParkingDoesnotExist", byteArrayOutputStream.toString().trim().replace(" ", ""));
		instance.createParkingLot(parkingSlot, 6);
		instance.park(parkingSlot, new Car("KA-01-HH-1234", "White"));
		instance.park(parkingSlot, new Car("KA-01-HH-9999", "White"));
		instance.fetchSlotNoFromRegistrationNo(parkingSlot, "KA-01-HH-1234");
		instance.fetchSlotNoFromRegistrationNo(parkingSlot, "KA-01-HH-9999");
		assertTrue("createdparkinglotwith5slots\nAllocatedslotnumber:1\nAllocatedslotnumber:2"
				.equalsIgnoreCase(byteArrayOutputStream.toString().trim().replace(" ", "")));
		instance.doCleanup();
	}
	
	@Test
	public void leave() throws Exception
	{
		thrown.expect(ParkingVehicleException.class);
		thrown.expectMessage(is(VehicleErrorCode.PARKING_NOT_EXIST_ERROR.getMessage()));
		instance.unPark(parkingSlot, 2);
		assertEquals("Sorry,CarParkingDoesnotExist", byteArrayOutputStream.toString().trim().replace(" ", ""));
		instance.createParkingLot(parkingSlot, 6);
		instance.park(parkingSlot, new Car("KA-01-HH-1234", "White"));
		instance.park(parkingSlot, new Car("KA-01-HH-9999", "White"));
		instance.park(parkingSlot, new Car("KA-01-BB-0001", "Black"));
		instance.unPark(parkingSlot, 4);
		assertTrue(
				"Sorry,CarParkingDoesnotExist\ncreatedparkinglotwith6slots\nAllocatedslotnumber:1\nAllocatedslotnumber:2\nAllocatedslotnumber:3\nSlotnumber4isfree"
						.equalsIgnoreCase(byteArrayOutputStream.toString().trim().replace(" ", "")));
		instance.doCleanup();
	}
	
	@Test
	public void testWhenVehicleAlreadyPresent() throws Exception
	{
		thrown.expect(ParkingVehicleException.class);
		thrown.expectMessage(is(VehicleErrorCode.PARKING_NOT_EXIST_ERROR.getMessage()));
		instance.park(parkingSlot, new Car("KA-01-HH-1234", "White"));
		assertEquals("Sorry,CarParkingDoesnotExist", byteArrayOutputStream.toString().trim().replace(" ", ""));
		instance.createParkingLot(parkingSlot, 4);
		instance.park(parkingSlot, new Car("KA-01-HH-1234", "White"));
		instance.park(parkingSlot, new Car("KA-01-HH-1234", "White"));
		assertTrue(
				"Sorry,CarParkingDoesnotExist\ncreatedparkinglotwith3slots\nAllocatedslotnumber:1\nSorry,vehicleisalreadyparked."
						.equalsIgnoreCase(byteArrayOutputStream.toString().trim().replace(" ", "")));
		instance.doCleanup();
	}
	
	@Test
	public void testWhenVehicleAlreadyPicked() throws Exception
	{
		thrown.expect(ParkingVehicleException.class);
		thrown.expectMessage(is(VehicleErrorCode.PARKING_NOT_EXIST_ERROR.getMessage()));
		instance.park(parkingSlot, new Car("KA-01-HH-1234", "White"));
		assertEquals("Sorry,CarParkingDoesnotExist", byteArrayOutputStream.toString().trim().replace(" ", ""));
		instance.createParkingLot(parkingSlot, 10);
		instance.park(parkingSlot, new Car("KA-01-HH-1234", "White"));
		instance.park(parkingSlot, new Car("KA-01-HH-9999", "White"));
		instance.unPark(parkingSlot, 2);
		instance.unPark(parkingSlot, 2);
		assertTrue(
				"Sorry,CarParkingDoesnotExist\ncreatedparkinglotwith99slots\nAllocatedslotnumber:1\nAllocatedslotnumber:2\nSlotnumberisEmptyAlready."
						.equalsIgnoreCase(byteArrayOutputStream.toString().trim().replace(" ", "")));
		instance.doCleanup();
	}
	
	@Test
	public void testStatus() throws Exception
	{
		thrown.expect(ParkingVehicleException.class);
		thrown.expectMessage(is(VehicleErrorCode.PARKING_NOT_EXIST_ERROR.getMessage()));
		instance.fetchStatus(parkingSlot);
		assertEquals("Sorry,CarParkingDoesnotExist", byteArrayOutputStream.toString().trim().replace(" ", ""));
		instance.createParkingLot(parkingSlot, 7);
		instance.park(parkingSlot, new Car("KA-01-HH-1234", "White"));
		instance.park(parkingSlot, new Car("KA-01-HH-9999", "White"));
		instance.fetchStatus(parkingSlot);
		assertTrue(
				"Sorry,CarParkingDoesnotExist\ncreatedparkinglotwith8slots\nAllocatedslotnumber:1\nAllocatedslotnumber:2\nSlotNo.\tRegistrationNo.\tColor\n1\tKA-01-HH-1234\tWhite\n2\tKA-01-HH-9999\tWhite"
						.equalsIgnoreCase(byteArrayOutputStream.toString().trim().replace(" ", "")));
		instance.doCleanup();
		
	}
	
	@Test
	public void testGetSlotsByRegNo() throws Exception
	{
		thrown.expect(ParkingVehicleException.class);
		thrown.expectMessage(is(VehicleErrorCode.PARKING_NOT_EXIST_ERROR.getMessage()));
		instance.fetchSlotNoFromRegistrationNo(parkingSlot, "KA-01-HH-1234");
		assertEquals("Sorry,CarParkingDoesnotExist", byteArrayOutputStream.toString().trim().replace(" ", ""));
		instance.createParkingLot(parkingSlot, 16);
		instance.park(parkingSlot, new Car("KA-01-HH-1234", "White"));
		instance.park(parkingSlot, new Car("KA-01-HH-9999", "White"));
		instance.fetchSlotNoFromRegistrationNo(parkingSlot, "KA-01-HH-1234");
		assertEquals("Sorry,CarParkingDoesnotExist\n" + "Createdparkinglotwith6slots\n" + "\n"
				+ "Allocatedslotnumber:1\n" + "\n" + "Allocatedslotnumber:2\n1",
				byteArrayOutputStream.toString().trim().replace(" ", ""));
		instance.fetchSlotNoFromRegistrationNo(parkingSlot, "KA-01-HH-1235");
		assertEquals(
				"Sorry,CarParkingDoesnotExist\n" + "Createdparkinglotwith10slots\n" + "\n" + "Allocatedslotnumber:1\n"
						+ "\n" + "Allocatedslotnumber:2\n1\nNotFound",
				byteArrayOutputStream.toString().trim().replace(" ", ""));
		instance.doCleanup();
	}
	
	@Test
	public void testGetSlotsByColor() throws Exception
	{
		thrown.expect(ParkingVehicleException.class);
		thrown.expectMessage(is(VehicleErrorCode.PARKING_NOT_EXIST_ERROR.getMessage()));
		instance.fetchRegNumberForColor(parkingSlot, "white");
		assertEquals("Sorry,CarParkingDoesnotExist", byteArrayOutputStream.toString().trim().replace(" ", ""));
		instance.createParkingLot(parkingSlot, 11);
		instance.park(parkingSlot, new Car("KA-01-HH-1234", "White"));
		instance.park(parkingSlot, new Car("KA-01-HH-9999", "White"));
		instance.fetchStatus(parkingSlot);
		instance.fetchRegNumberForColor(parkingSlot, "White");
		assertEquals(
				"Sorry,CarParkingDoesnotExist\n" + "Createdparkinglotwith7slots\n" + "\n" + "Allocatedslotnumber:1\n"
						+ "\n" + "Allocatedslotnumber:2\nKA-01-HH-1234,KA-01-HH-9999",
				byteArrayOutputStream.toString().trim().replace(" ", ""));
		instance.fetchRegNumberForColor(parkingSlot, "Blue");
		assertEquals(
				"Sorry,CarParkingDoesnotExist\n" + "Createdparkinglotwith6slots\n" + "\n" + "Allocatedslotnumber:1\n"
						+ "\n" + "Allocatedslotnumber:2\n" + "KA-01-HH-1234,KA-01-HH-9999,Notfound",
				byteArrayOutputStream.toString().trim().replace(" ", ""));
		instance.doCleanup();
		
	}
}
