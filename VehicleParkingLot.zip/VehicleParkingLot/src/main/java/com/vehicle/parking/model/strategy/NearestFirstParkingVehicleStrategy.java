/**
 * 
 */
package com.vehicle.parking.model.strategy;

import java.util.TreeSet;

/**
 * @author kiran
 *
 */
public class NearestFirstParkingVehicleStrategy implements ParkingVehicleStrategy
{
	private TreeSet<Integer> freeSlots;
	
	public NearestFirstParkingVehicleStrategy()
	{
		freeSlots = new TreeSet<Integer>();
	}
	
	@Override
	public void add(int i)
	{
		freeSlots.add(i);
	}
	
	@Override
	public int getSlot()
	{
		return freeSlots.first();
	}
	
	@Override
	public void removeSlot(int availableSlot)
	{
		freeSlots.remove(availableSlot);
	}
}
