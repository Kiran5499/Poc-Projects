/**
 * 
 */
package com.vehicle.parking.service;

import java.util.Optional;

import com.vehicle.parking.exception.ParkingVehicleException;
import com.vehicle.parking.model.Vehicle;

/**
 * @author kiran
 *
 */
public interface ParkingVehicleService extends AbstractService
{
	public void createParkingLot(int level, int capacity) throws ParkingVehicleException;
	
	public Optional<Integer> park(int level, Vehicle vehicle) throws ParkingVehicleException;
	
	public void unPark(int level, int slotNumber) throws ParkingVehicleException;
	
	public void fetchStatus(int level) throws ParkingVehicleException;
	
	public Optional<Integer> fetchAvailableSlotsCount(int level) throws ParkingVehicleException;
	
	public void fetchRegNumberForColor(int level, String color) throws ParkingVehicleException;
	
	public void fetchSlotNumbersFromColor(int level, String colour) throws ParkingVehicleException;
	
	public int fetchSlotNoFromRegistrationNo(int level, String registrationNo) throws ParkingVehicleException;
	
	public void doCleanup();
}
