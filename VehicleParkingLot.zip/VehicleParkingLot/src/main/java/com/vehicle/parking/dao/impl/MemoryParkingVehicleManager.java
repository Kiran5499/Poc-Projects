/**
 * 
 */
package com.vehicle.parking.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.vehicle.parking.dao.ParkingVehicleDataManager;
import com.vehicle.parking.dao.ParkingVehicleLevelDataManager;
import com.vehicle.parking.model.Vehicle;
import com.vehicle.parking.model.strategy.NearestFirstParkingVehicleStrategy;
import com.vehicle.parking.model.strategy.ParkingVehicleStrategy;

/**
 * This class is a singleton class to manage the data of parking system
 * 
 * @author kiran
 * @param <T>
 */
public class MemoryParkingVehicleManager<T extends Vehicle> implements ParkingVehicleDataManager<T>
{
	private Map<Integer, ParkingVehicleLevelDataManager<T>> levelParkingMap;
	
	@SuppressWarnings("rawtypes")
	private static MemoryParkingVehicleManager instance = null;
	
	@SuppressWarnings("unchecked")
	public static <T extends Vehicle> MemoryParkingVehicleManager<T> getInstance(List<Integer> parkingLevels,
			List<Integer> capacityList, List<ParkingVehicleStrategy> parkingVehicleStrategies)
	{
		// Make sure the each of the lists are of equal size
		if (instance == null)
		{
			synchronized (MemoryParkingVehicleManager.class)
			{
				if (instance == null)
				{
					instance = new MemoryParkingVehicleManager<T>(parkingLevels, capacityList,
							parkingVehicleStrategies);
				}
			}
		}
		return instance;
	}
	
	private MemoryParkingVehicleManager(List<Integer> parkingLevels, List<Integer> capacityList,
			List<ParkingVehicleStrategy> parkingVehicleStrategies)
	{
		if (levelParkingMap == null)
			levelParkingMap = new HashMap<>();
		for (int i = 0; i < parkingLevels.size(); i++)
		{
			levelParkingMap.put(parkingLevels.get(i), MemoryParkingVehicleLevelManager.getInstance(parkingLevels.get(i),
					capacityList.get(i), new NearestFirstParkingVehicleStrategy()));
			
		}
	}
	
	@Override
	public int parkCar(int level, T vehicle)
	{
		return levelParkingMap.get(level).parkCar(vehicle);
	}
	
	@Override
	public boolean leaveCar(int level, int slotNumber)
	{
		return levelParkingMap.get(level).leaveCar(slotNumber);
	}
	
	@Override
	public List<String> fetchStatus(int level)
	{
		return levelParkingMap.get(level).getStatus();
	}
	
	public int fetchAvailableSlotsCount(int level)
	{
		return levelParkingMap.get(level).getAvailableSlotsCount();
	}
	
	@Override
	public List<String> fetchRegNumberForColor(int level, String color)
	{
		return levelParkingMap.get(level).getRegNumberForColor(color);
	}
	
	@Override
	public List<Integer> fetchSlotNumbersFromColor(int level, String color)
	{
		return levelParkingMap.get(level).getSlotNumbersFromColor(color);
	}
	
	@Override
	public int fetchSlotNoFromRegistrationNo(int level, String registrationNo)
	{
		return levelParkingMap.get(level).getSlotNoFromRegistrationNo(registrationNo);
	}
	
	public Object clone() throws CloneNotSupportedException
	{
		throw new CloneNotSupportedException();
	}
	
	public void doCleanup()
	{
		for (ParkingVehicleLevelDataManager<T> levelDataManager : levelParkingMap.values())
		{
			levelDataManager.doCleanUp();
		}
		levelParkingMap = null;
		instance = null;
	}
}
