package com.vehicle.parking;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.vehicle.parking.constants.VehicleConstants;
import com.vehicle.parking.exception.ParkingVehicleException;
import com.vehicle.parking.exception.VehicleErrorCode;
import com.vehicle.parking.processor.AbstractProcessor;
import com.vehicle.parking.processor.VehicleRequestProcessor;
import com.vehicle.parking.service.impl.ParkingVehicleServiceImpl;

/**
 * @author kiran
 *
 */
public class ParkingMain
{
	public static void main(String[] args)
	{
		AbstractProcessor processor = new VehicleRequestProcessor();
		processor.setService(new ParkingVehicleServiceImpl());
		BufferedReader bufferReader = null;
		String input = null;
		try
		{
			System.out.println("        HI-TECH CITY PARKING LOT             ");
			System.out.println("        ------------------------        \n");
			printUsage();
			switch (args.length)
			{
				case 0: // Interactive: command-line input/output
				{
					System.out.println("Please Enter 'exit' to end Execution");
					System.out.println("Input::");
					while (true)
					{
						try
						{
							bufferReader = new BufferedReader(new InputStreamReader(System.in));
							input = bufferReader.readLine().trim();
							if (input.equalsIgnoreCase("exit"))
							{
								break;
							}
							else
							{
								if (processor.validate(input))
								{
									try
									{
										processor.execute(input.trim());
									}
									catch (Exception e)
									{
										System.out.println(e.getMessage());
									}
								}
								else
								{
									printUsage();
								}
							}
						}
						catch (Exception e)
						{
							throw new ParkingVehicleException(VehicleErrorCode.INVALID_REQUEST.getMessage(), e);
						}
					}
					break;
				}
				case 1:// File input/output
				{
					File inputFile = new File(args[0]);
					try
					{
						bufferReader = new BufferedReader(new FileReader(inputFile));
						int lineNo = 1;
						while ((input = bufferReader.readLine()) != null)
						{
							input = input.trim();
							if (processor.validate(input))
							{
								try
								{
									processor.execute(input);
								}
								catch (Exception e)
								{
									System.out.println(e.getMessage());
								}
							}
							else
								System.out.println("Incorrect Command Found at line: " + lineNo + " ,Input: " + input);
							lineNo++;
						}
					}
					catch (Exception e)
					{
						throw new ParkingVehicleException(VehicleErrorCode.INVALID_FILE.getMessage(), e);
					}
					break;
				}
				default:
					System.out.println("Invalid input. Usage Style: java -jar <jar_file_path> <input_file_path>");
			}
		}
		catch (ParkingVehicleException e)
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		finally
		{
			try
			{
				if (bufferReader != null)
					bufferReader.close();
			}
			catch (IOException e)
			{
			}
		}
	}
	
	/**
	 * To do list for parking
	 */
	private static void printUsage()
	{
		StringBuffer buffer = new StringBuffer();
		buffer = buffer.append("Choose choice for parking operation:::::: ").append("\n\n");
		buffer = buffer.append("1." + VehicleConstants.CREATE_PARKING_LOT + " {Integer Number}").append("\n");
		buffer = buffer.append("2." + VehicleConstants.PARK + " <<car_number>> " + " {Colour}").append("\n");
		buffer = buffer.append("3." + VehicleConstants.LEAVE + " {slot_number}").append("\n");
		buffer = buffer.append("4." + VehicleConstants.STATUS).append("\n");
		buffer = buffer.append("5." + VehicleConstants.REG_NUMBER_FOR_CARS_WITH_COLOR + " {car_color}").append("\n");
		buffer = buffer.append("6." + VehicleConstants.SLOTS_NUMBER_FOR_CARS_WITH_COLOR + " {car_color}").append("\n");
		buffer = buffer.append("7." + VehicleConstants.SLOTS_NUMBER_FOR_REG_NUMBER + " {car_number}").append("\n");
		System.out.println(buffer.toString());
	}
}
