/**
 * 
 */
package com.vehicle.parking.model.strategy;

/**
 * @author kiran
 *
 */
public interface ParkingVehicleStrategy
{
	public void add(int i);
	
	public int getSlot();
	
	public void removeSlot(int slot);
}
