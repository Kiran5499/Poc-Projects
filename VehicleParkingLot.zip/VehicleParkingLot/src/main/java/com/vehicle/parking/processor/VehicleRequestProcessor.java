/**
 * 
 */
package com.vehicle.parking.processor;

import com.vehicle.parking.constants.VehicleConstants;
import com.vehicle.parking.exception.ParkingVehicleException;
import com.vehicle.parking.exception.VehicleErrorCode;
import com.vehicle.parking.model.Car;
import com.vehicle.parking.service.AbstractService;
import com.vehicle.parking.service.ParkingVehicleService;

/**
 * 
 * @author kiran
 */
public class VehicleRequestProcessor implements AbstractProcessor
{
	private ParkingVehicleService parkingVehicleService;
	
	public void setParkingService(ParkingVehicleService parkingVehicleService) throws ParkingVehicleException
	{
		this.parkingVehicleService = parkingVehicleService;
	}
	
	@Override
	public void execute(String input) throws ParkingVehicleException
	{
		int level = 1;
		String[] inputs = input.split(" ");
		String key = inputs[0];
		switch (key)
		{
			case VehicleConstants.CREATE_PARKING_LOT:
				try
				{
					int capacity = Integer.parseInt(inputs[1]);
					parkingVehicleService.createParkingLot(level, capacity);
				}
				catch (NumberFormatException e)
				{
					throw new ParkingVehicleException(
							VehicleErrorCode.INVALID_VALUE.getMessage().replace("{variable}", "capacity"));
				}
				break;
			case VehicleConstants.PARK:
				parkingVehicleService.park(level, new Car(inputs[1], inputs[2]));
				break;
			case VehicleConstants.LEAVE:
				try
				{
					int slotNumber = Integer.parseInt(inputs[1]);
					parkingVehicleService.unPark(level, slotNumber);
				}
				catch (NumberFormatException e)
				{
					throw new ParkingVehicleException(
							VehicleErrorCode.INVALID_VALUE.getMessage().replace("{variable}", "slot_number"));
				}
				break;
			case VehicleConstants.STATUS:
				parkingVehicleService.fetchStatus(level);
				break;
			case VehicleConstants.REG_NUMBER_FOR_CARS_WITH_COLOR:
				parkingVehicleService.fetchRegNumberForColor(level, inputs[1]);
				break;
			case VehicleConstants.SLOTS_NUMBER_FOR_CARS_WITH_COLOR:
				parkingVehicleService.fetchSlotNumbersFromColor(level, inputs[1]);
				break;
			case VehicleConstants.SLOTS_NUMBER_FOR_REG_NUMBER:
				parkingVehicleService.fetchSlotNoFromRegistrationNo(level, inputs[1]);
				break;
			default:
				break;
		}
	}
	
	@Override
	public void setService(AbstractService service)
	{
		this.parkingVehicleService = (ParkingVehicleService) service;
	}
}
