/**
 * 
 */
package com.vehicle.parking.dao;

import java.util.List;

import com.vehicle.parking.model.Vehicle;

/**
 * @author kiran
 *
 */
public interface ParkingVehicleDataManager<T extends Vehicle>
{
	public int parkCar(int level, T vehicle);
	
	public boolean leaveCar(int level, int slotNumber);
	
	public List<String> fetchStatus(int level);
	
	public List<String> fetchRegNumberForColor(int level, String color);
	
	public List<Integer> fetchSlotNumbersFromColor(int level, String colour);
	
	public int fetchSlotNoFromRegistrationNo(int level, String registrationNo);
	
	public int fetchAvailableSlotsCount(int level);
	
	public void doCleanup();
}
