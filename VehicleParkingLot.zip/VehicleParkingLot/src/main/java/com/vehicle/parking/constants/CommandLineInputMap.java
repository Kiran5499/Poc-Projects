/**
 * 
 */
package com.vehicle.parking.constants;

import java.util.HashMap;
import java.util.Map;

/**
 * @author kiran
 *
 */
public class CommandLineInputMap
{
	private static volatile Map<String, Integer> commandsParameterMap = new HashMap<String, Integer>();
	
	static
	{
		commandsParameterMap.put(VehicleConstants.CREATE_PARKING_LOT, 1);
		commandsParameterMap.put(VehicleConstants.PARK, 2);
		commandsParameterMap.put(VehicleConstants.LEAVE, 1);
		commandsParameterMap.put(VehicleConstants.STATUS, 0);
		commandsParameterMap.put(VehicleConstants.REG_NUMBER_FOR_CARS_WITH_COLOR, 1);
		commandsParameterMap.put(VehicleConstants.SLOTS_NUMBER_FOR_CARS_WITH_COLOR, 1);
		commandsParameterMap.put(VehicleConstants.SLOTS_NUMBER_FOR_REG_NUMBER, 1);
	}
	
	/**
	 * @return the commandsParameterMap
	 */
	public static Map<String, Integer> getCommandsParameterMap()
	{
		return commandsParameterMap;
	}
	
	/**
	 * @param commandsParameterMap
	 *            the commandsParameterMap to set
	 */
	public static void addCommand(String command, int parameterCount)
	{
		commandsParameterMap.put(command, parameterCount);
	}
	
}
