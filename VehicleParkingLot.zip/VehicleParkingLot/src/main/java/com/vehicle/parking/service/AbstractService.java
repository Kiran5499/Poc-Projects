package com.vehicle.parking.service;

/**
 * This is a marker Interface for all services
 * 
 * @author kiran
 */
public interface AbstractService
{
	
}
